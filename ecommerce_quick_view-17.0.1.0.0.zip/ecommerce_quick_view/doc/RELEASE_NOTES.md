## Module <ecommerce_quick_view>

#### 15.04.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Product Quickview in e-Commerce
