## Module <individual_product_report>

#### 16.12.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Product Sale Report Graph View
