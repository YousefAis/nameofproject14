## Module <dynamic_product_fields>

#### 13.12.2023
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for Product Custom Fields

#### 18.04.2024
#### Version 17.0.1.0.1
##### UPDT
- Added Migration Script
